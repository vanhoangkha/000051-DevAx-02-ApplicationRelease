package idevelop.samples;

import com.amazonaws.services.elasticbeanstalk.AWSElasticBeanstalk;
import com.amazonaws.services.elasticbeanstalk.AWSElasticBeanstalkClientBuilder;
import com.amazonaws.services.elasticbeanstalk.model.ApplicationDescription;
import com.amazonaws.services.elasticbeanstalk.model.ApplicationVersionDescription;
import com.amazonaws.services.elasticbeanstalk.model.DescribeApplicationVersionsRequest;
import com.amazonaws.services.elasticbeanstalk.model.DescribeApplicationVersionsResult;
import com.amazonaws.services.elasticbeanstalk.model.DescribeApplicationsResult;

public class AWSBeanstalkManager {
	
	private AWSElasticBeanstalk eb = null;
	
	public AWSBeanstalkManager()
	{
		this.eb = AmazonElasticBeanstalkClientFactory.getClient();
	}
	
	public void ListApplications() 
	{       
		DescribeApplicationsResult result = eb.describeApplications();

		for ( ApplicationDescription app : result.getApplications() )
		{
			System.out.println("     APP: " + app.getApplicationName());	
		}
    }

	public void ListApplicationsAndVersions() 
	{       
		DescribeApplicationsResult result = eb.describeApplications();

		for ( ApplicationDescription app : result.getApplications() )
		{
			System.out.println("========================================");
			System.out.println("     APP: " + app.getApplicationName());
			
			DescribeApplicationVersionsResult versions = eb.describeApplicationVersions(
					new DescribeApplicationVersionsRequest()
					.withApplicationName(app.getApplicationName())
					);
			
			for ( ApplicationVersionDescription versDescriptor : versions.getApplicationVersions() )
			{
				System.out.println("               VERSION: " + versDescriptor.getVersionLabel());
				System.out.println("               CREATED: " + versDescriptor.getDateCreated());
				System.out.println("              MODIFIED: " + versDescriptor.getDateUpdated());
				System.out.println("            BUCKET/KEY: " + versDescriptor.getSourceBundle().getS3Bucket() + "/" + versDescriptor.getSourceBundle().getS3Key());
				System.out.println("");
			}
			
			System.out.println("========================================\n\n");

		}
    }

}


