package idevelop.samples;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import com.amazonaws.services.s3.model.Region;

public class Application {

	public static int menu() {
	
	    int selection;
	    Scanner input = new Scanner(System.in);

        System.out.println("-------------------------");
        System.out.println("Main Menu");
        System.out.println("-------------------------\n");
        System.out.println("0 - Quit");
        System.out.println("1 - List Beanstalk Applications");
        System.out.println("2 - List Beanstalk Applications with their versions");
	    	
	    selection = input.nextInt();
	    return selection;    
	}
	
	public static void main(String[] args) {

		
        System.out.println("===========================================");
        System.out.println("Welcome to iDevelop<AWS>!");
        System.out.println("===========================================");

        AWSBeanstalkManager ebManager = new AWSBeanstalkManager();
        
		int menuChoice = -1;
		
		while (menuChoice != 0) {
			
			try
			{
				menuChoice = menu();
				
				Scanner input = new Scanner(System.in);
				
				switch ( menuChoice ) {
							
					case 0:
						System.out.println("\nExiting!");
						break;
					
					case 1:
						ebManager.ListApplications();
						break;
					
					case 2:
						ebManager.ListApplicationsAndVersions();
						break;
					
						
				}
				
			}
			catch(Exception ex)
			{
				System.out.println("\n===========================================");
				System.out.println("EXCEPTION: " + ex.getMessage());
				System.out.println("===========================================\n");
			}
		}
			
        

        
    }
}

