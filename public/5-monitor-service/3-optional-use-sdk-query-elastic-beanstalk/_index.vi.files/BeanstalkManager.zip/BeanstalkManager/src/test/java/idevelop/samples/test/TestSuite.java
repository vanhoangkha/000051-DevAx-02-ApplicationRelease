package idevelop.samples.test;

import java.io.File;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.junit.MockitoJUnitRunner;

import com.amazonaws.services.s3.model.Region;

import idevelop.samples.AWSBeanstalkManager;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestSuite {

	@BeforeClass
    public static void setUp() {
		
		System.out.println("==================================");
		System.out.println("Starting Test Suite");
		System.out.println("==================================\n");
		System.out.println("Testing " + AWSBeanstalkManager.class.getName());
    }
	
    @Test
    public void test_A_ListApplications() {

    	AWSBeanstalkManager eb = new AWSBeanstalkManager();    	
    	eb.ListApplications();
    }

    @Test
    public void test_BListApplicationsAndVersions() {

    	AWSBeanstalkManager eb = new AWSBeanstalkManager();    	
    	eb.ListApplicationsAndVersions();
    }
}
